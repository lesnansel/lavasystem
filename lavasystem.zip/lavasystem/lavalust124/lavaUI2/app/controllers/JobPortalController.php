<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class JobPortalController extends Controller {
    public function __construct()
    {
        parent::__construct();
        $this->call->model('job_model'); // Load the job model
    }

    // Function to list all jobs
    public function read()
    {
        $data['jobs'] = $this->job_model->read();
        $this->call->view('jobs/view_jobs', $data);
    }

    // Function to create a new job listing
    public function create()
    {
        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->name('JobTitle')->required('Job Title is required!')
                ->name('Company')->required('Company Name is required!')
                ->name('Location')->required('Location is required!')
                ->name('Description')->required('Job Description is required!')
                ->name('Salary')->required('Salary is required!');

            if ($this->form_validation->run()) {
                $jobData = [
                    'title' => $this->io->post('JobTitle'),
                    'company' => $this->io->post('Company'),
                    'location' => $this->io->post('Location'),
                    'description' => $this->io->post('Description'),
                    'salary' => $this->io->post('Salary'),
                ];

                if ($this->job_model->create($jobData)) {
                    set_flash_alert('success', 'Job created successfully!');
                    redirect('admin/jobs/read');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }
        $this->call->view('jobs/add_job');
    }

    // Function to update an existing job listing
    public function update($id)
    {
        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->name('JobTitle')->required('Job Title is required!')
                ->name('Company')->required('Company Name is required!')
                ->name('Location')->required('Location is required!')
                ->name('Description')->required('Job Description is required!')
                ->name('Salary')->required('Salary is required!');

            if ($this->form_validation->run()) {
                $jobData = [
                    'title' => $this->io->post('JobTitle'),
                    'company' => $this->io->post('Company'),
                    'location' => $this->io->post('Location'),
                    'description' => $this->io->post('Description'),
                    'salary' => $this->io->post('Salary'),
                ];

                if ($this->job_model->update($id, $jobData)) {
                    set_flash_alert('success', 'Job updated successfully!');
                    redirect('admin/jobs/read');
                } else {
                    set_flash_alert('danger', 'Failed to update the job.');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }

        $data['job'] = $this->job_model->get_one($id);
        $this->call->view('jobs/edit_job', $data);
    }

    // Function to delete a job listing
    public function delete($id)
    {
        if ($this->job_model->delete($id)) {
            set_flash_alert('success', 'Job deleted successfully!');
        } else {
            set_flash_alert('danger', 'Failed to delete the job.');
        }
        redirect('admin/jobs/read');
    }

    // Function for users to view available jobs
    public function list_jobs()
    {
        $data['jobs'] = $this->job_model->read();
        $this->call->view('jobs/user_jobs', $data);
    }

    // Function for users to apply for a job
    public function apply($jobId)
    {
        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->name('ApplicantName')->required('Your Name is required!')
                ->name('Email')->required('Email is required!')->valid_email('Enter a valid email address.')
                ->name('Resume')->required('Resume is required!');

            if ($this->form_validation->run()) {
                $applicationData = [
                    'job_id' => $jobId,
                    'applicant_name' => $this->io->post('ApplicantName'),
                    'email' => $this->io->post('Email'),
                    'resume' => $this->io->post('Resume'),
                ];

                if ($this->job_model->apply($applicationData)) {
                    set_flash_alert('success', 'Your application was submitted successfully!');
                    redirect('jobs/list');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
            }
        }

        $data['job'] = $this->job_model->get_one($jobId);
        $this->call->view('jobs/apply_job', $data);
    }
}
