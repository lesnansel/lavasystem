<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class JobController extends Controller {
    public function __construct()
    {
        parent::__construct();
        $this->call->model('job_model'); // Reference to the job model
    }

    public function job_read()
    {
        $data['jobs'] = $this->job_model->read();
        $this->call->view('job/manage_job', $data);
    }

    public function create()
    {
        if ($this->form_validation->submitted()) {
            $this->form_validation
                ->name('JobTitle')
                ->required('Job Title is required!')
                ->name('Description')
                ->required('Description is required!')
                ->name('Salary')
                ->required('Salary is required!')
                ->name('Location')
                ->required('Location is required!')
                ->name('Schedule')
                ->required('Schedule is required!');

            if ($this->form_validation->run()) {
                $data = [
                    'JobTitle' => $this->io->post('JobTitle'),
                    'Description' => $this->io->post('Description'),
                    'Salary' => $this->io->post('Salary'),
                    'Location' => $this->io->post('Location'),
                    'Schedule' => $this->io->post('Schedule'),
                ];

                if ($this->job_model->create($data)) {
                    set_flash_alert('success', 'Job posting was added successfully!');
                    redirect('job/display');
                }
            } else {
                set_flash_alert('danger', $this->form_validation->errors());
                redirect('job/add');
            }
        }

        $this->call->view('job/add_job');
    }

    public function update($id)
{
    if ($this->form_validation->submitted()) {
        // Validate the required fields
        $this->form_validation
            ->name('Title')
            ->required('Job Title is required!')
            ->name('Description')
            ->required('Description is required!')
            ->name('Salary')
            ->required('Salary is required!')
            ->name('Location')
            ->required('Location is required!')
            ->name('Company')
            ->required('Company is required!')
            ->name('JobType')
            ->required('Job Type is required!')
            ->name('PostingDate')
            ->required('Posting Date is required!');

        if ($this->form_validation->run()) {
            // Prepare the data array based on form input
            $data = [
                'Title' => $this->io->post('Title'),
                'Description' => $this->io->post('Description'),
                'Requirements' => $this->io->post('Requirements'),
                'Salary' => $this->io->post('Salary'),
                'Location' => $this->io->post('Location'),
                'Company' => $this->io->post('Company'),
                'JobType' => $this->io->post('JobType'),
                'PostingDate' => $this->io->post('PostingDate'),
            ];

            // Update the job posting in the database
            if ($this->job_model->update($id, $data)) {
                set_flash_alert('success', 'Job posting was updated successfully!');
                redirect('auth/job/display');
            } else {
                set_flash_alert('danger', 'Failed to update job posting.');
                redirect('auth/job/display' . $id);
            }
        } else {
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('auth/job/display' . $id);
        }
    }

    // Fetch the job details for editing
    $data['job'] = $this->job_model->get_one($id);
    $this->call->view('job/edit_job', $data);
}


    public function delete($id)
    {
        if ($this->job_model->delete($id)) {
            set_flash_alert('success', 'Job posting was deleted successfully!');
            redirect('job/display');
        } else {
            set_flash_alert('danger', 'Failed to delete job posting.');
            redirect('job/display');
        }
    }
}
