<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class UserDashboard extends Controller {

    public function __construct() {
        parent::__construct();
        
        if(! logged_in()) {
            redirect('user');
        }
    }



    //added function for job creation
    public function create() {
        $title = $this->input->post('title');
        $description = $this->input->post('description');
        $requirements = $this->input->post('requirements');
        $salary = $this->input->post('salary');
        $location = $this->input->post('location');
        $job_type = $this->input->post('job_type');
        $employer_id = $this->session->userdata('user_id');
    
        $this->model->create_job_listing($employer_id, $title, $description, $requirements, $salary, $location, $job_type);
    
        redirect('job/listings');
    }

    //for job search
    public function search() {
        $query = $this->input->get('query');
        $data['jobs'] = $this->model->search_jobs($query);
        $this->load->view('job_listings', $data);
    }

    //for job sending message
    public function send() {
        $message = $this->input->post('message');
        $receiver_id = $this->input->post('receiver_id');
        $sender_id = $this->session->userdata('user_id');
    
        $this->model->send_message($sender_id, $receiver_id, $message);
    
        redirect('message/index/' . $receiver_id);
    }

    //for job bookmarking
    public function bookmark($job_id) {
        $user_id = $this->session->userdata('user_id');
        $this->model->bookmark_job($user_id, $job_id);
    
        redirect('job/listings');
    }

	public function index() {
        
        $this->call->view('user_dashboard');
    }
}
?>
