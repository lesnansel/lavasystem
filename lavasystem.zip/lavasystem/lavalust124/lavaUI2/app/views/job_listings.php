<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Browse and apply for the latest job openings">
    <title>Job Listings</title>
    <link rel="stylesheet" href="path/to/bootstrap.css">
    <style>
        .job-item {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .job-item h3 {
            margin: 0 0 10px;
        }
        .job-item p {
            color: #555;
        }
        .btn-group {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <header class="mb-4">
            <h1 class="text-center">Available Job Listings</h1>
            <p class="text-center text-muted">Find your next career opportunity below</p>
        </header>

        <!-- Job Search Form -->
        <form action="<?= site_url('job/search'); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input 
                    type="text" 
                    name="query" 
                    placeholder="Search jobs by title, company, or location..." 
                    class="form-control" 
                    aria-label="Search jobs"
                >
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </form>

        <!-- Job Listings -->
        <div class="job-list">
            <?php if (!empty($jobs)): ?>
                <?php foreach ($jobs as $job): ?>
                    <div class="job-item">
                        <h3><?= htmlspecialchars($job['title']); ?></h3>
                        <p><strong>Company:</strong> <?= htmlspecialchars($job['company']); ?></p>
                        <p><strong>Location:</strong> <?= htmlspecialchars($job['location']); ?></p>
                        <p><?= nl2br(htmlspecialchars($job['description'])); ?></p>
                        <div class="btn-group">
                            <a href="<?= site_url('job/apply/' . $job['id']); ?>" class="btn btn-success">Apply Now</a>
                            <a href="<?= site_url('job/bookmark/' . $job['id']); ?>" class="btn btn-warning">Bookmark</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="alert alert-info text-center">
                    <strong>No job listings found.</strong> Try adjusting your search or check back later!
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
