<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #343a40;
            --secondary-color: #495057;
            --text-color: #f8f9fa;
            --hover-color: #6c757d;
            --transition-speed: 0.3s;
        }

        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: var(--primary-color);
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
            color: var(--text-color);
            transition: transform var(--transition-speed);
            z-index: 1000;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: var(--text-color);
            transition: background var(--transition-speed);
        }

        .sidebar a:hover {
            background-color: var(--secondary-color);
        }

        .sidebar a .icon {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left var(--transition-speed);
        }

        .card {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background-color: var(--primary-color);
            color: var(--text-color);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content.active {
                margin-left: 250px;
            }
        }

        /* Utility classes */
        .mb-4 { margin-bottom: 1rem; }
        .text-lg { font-size: 1.125rem; }
        .font-bold { font-weight: bold; }
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <a href="#" class="navbar-brand mx-3 mb-4">
            <strong>Job Portal Admin</strong>
        </a>
        <a class="nav-link" href="#">
            <span class="icon"><i class="fas fa-user"></i></span>
            <?=html_escape(get_username(get_user_id()));?>
        </a>
        <a href="<?=site_url('dashboard')?>" class="active">
            <span class="icon"><i class="fas fa-tachometer-alt"></i></span> Dashboard
        </a>
        <a href="<?= site_url('jobs/manage'); ?>">
            <span class="icon"><i class="fas fa-briefcase"></i></span> Manage Jobs
        </a>
        <a href="<?= site_url('applications/manage'); ?>">
            <span class="icon"><i class="fas fa-file-alt"></i></span> Manage Applications
        </a>
        <a href="<?= site_url('jobs/create'); ?>">
            <span class="icon"><i class="fas fa-plus-circle"></i></span> Post a Job
        </a>
        <a href="#analytics">
            <span class="icon"><i class="fas fa-chart-bar"></i></span> Analytics
        </a>
        <a href="<?=site_url('auth/logout');?>" class="mt-auto">
            <span class="icon"><i class="fas fa-sign-out-alt"></i></span> Logout
        </a>
    </div>

    <!-- Main content -->
    <div class="main-content" id="main-content">
        <div class="container">
            <h1 class="mb-4 text-lg font-bold">Dashboard</h1>
            
            <div class="stats-grid mb-4">
                <div class="stat-card">
                    <h3>120</h3>
                    <p>Total Job Postings</p>
                </div>
                <div class="stat-card">
                    <h3>500</h3>
                    <p>Total Applications</p>
                </div>
                <div class="stat-card">
                    <h3>30</h3>
                    <p>Active Employers</p>
                </div>
                <div class="stat-card">
                    <h3>92%</h3>
                    <p>Application Success Rate</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <h2 class="text-lg font-bold mb-4">Job Post Distribution</h2>
                        <div class="chart-container">
                            <canvas id="jobChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <h2 class="text-lg font-bold mb-4">Applications Trend</h2>
                        <div class="chart-container">
                            <canvas id="applicationChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2 class="text-lg font-bold mb-4">Recent Activities</h2>
                <ul class="list-group">
                    <li class="list-group-item">New job posted: Software Developer at ABC Corp</li>
                    <li class="list-group-item">New application received for Marketing Manager</li>
                    <li class="list-group-item">Job posting updated: Senior Designer</li>
                    <li class="list-group-item">Payment processed for Premium Job Plan</li>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script>
        // Charts
        const jobCtx = document.getElementById('jobChart').getContext('2d');
        new Chart(jobCtx, {
            type: 'doughnut',
            data: {
                labels: ['IT', 'Finance', 'Marketing', 'Other'],
                datasets: [{
                    data: [40, 20, 30, 10],
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
                }]
            }
        });

        const applicationCtx = document.getElementById('applicationChart').getContext('2d');
        new Chart(applicationCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Applications',
                    data: [120, 150, 170, 200, 220, 250],
                    borderColor: '#36A2EB',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
