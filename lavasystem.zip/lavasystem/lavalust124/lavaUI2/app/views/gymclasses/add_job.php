<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add New Job - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', Arial, sans-serif;
        }
        .sidebar {
            background-color: #343a40;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
            color: #fff;
        }
        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            color: #fff;
            transition: background 0.3s;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .sidebar a .icon {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .form-container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-container h1 {
            margin-bottom: 20px;
        }
        .form-container label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php
    include APP_DIR.'views/templates/adminsidebar.php';
    ?>

    <!-- Main content -->
    <div class="main-content">
        <div class="container">
            <div class="form-container">
                <h1>Add New Job</h1>
                <form action="<?= site_url('job/create'); ?>" method="POST">
                    <label for="title">Job Title:</label>
                    <input type="text" name="title" class="form-control mb-3" required>
                    
                    <label for="description">Job Description:</label>
                    <textarea name="description" class="form-control mb-3" required></textarea>
                    
                    <label for="requirements">Job Requirements:</label>
                    <textarea name="requirements" class="form-control mb-3" required></textarea>
                    
                    <label for="salary">Salary:</label>
                    <input type="number" step="0.01" name="salary" class="form-control mb-3" required>
                    
                    <label for="location">Location:</label>
                    <input type="text" name="location" class="form-control mb-3" required>
                    
                    <label for="company">Company Name:</label>
                    <input type="text" name="company" class="form-control mb-3" required>
                    
                    <label for="job_type">Job Type:</label>
                    <select name="job_type" class="form-control mb-3" required>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Freelance">Freelance</option>
                    </select>
                    
                    <label for="schedule">Job Posting Schedule:</label>
                    <input type="datetime-local" name="schedule" class="form-control mb-4" required>
                    
                    <button type="submit" class="btn btn-primary">Post Job</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
