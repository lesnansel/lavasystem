<!doctype html>
<html lang="en" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Job Portal</title>
    <link rel="icon" type="image/png" href="favicon.ico"/>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&family=Oswald:wght@400;700&display=swap" rel="stylesheet">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'nunito': ['Nunito', 'sans-serif'],
                        'oswald': ['Oswald', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        .bg-jobportal {
            background-image: url('https://images.unsplash.com/photo-1522199755839-a2bacb67c546?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzNzU1MDF8MHwxfGFsbHwxfHx8fHx8fHwxNjcwMTgzOTY1&ixlib=rb-1.2.1&q=80&w=1080');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body class="h-full font-nunito text-white bg-jobportal">
    <div class="h-full bg-black bg-opacity-70 flex flex-col">
        <nav class="bg-black bg-opacity-80 shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-20 items-center">
                    <div class="flex">
                        <a class="flex items-center text-2xl font-oswald font-bold text-yellow-500" href="#">
                            JOB PORTAL
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a class="text-gray-300 hover:text-yellow-500 px-3 py-2 rounded-md text-lg font-medium transition duration-300" href="#">Login</a>
                        <a class="text-gray-300 hover:text-yellow-500 px-3 py-2 rounded-md text-lg font-medium transition duration-300" href="#">Register</a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="flex-grow py-8">
            <div class="max-w-md mx-auto py-6 sm:px-6 lg:px-8">
                <div class="bg-black bg-opacity-80 rounded-lg overflow-hidden shadow-2xl">
                    <div class="px-6 py-4 bg-yellow-600 border-b border-yellow-700">
                        <h2 class="text-2xl font-oswald font-bold text-white">USER LOGIN</h2>
                    </div>
                    <div class="p-6">
                        <form id="loginForm" method="POST" action="login_endpoint">
                            <div class="mb-5">
                                <label for="email" class="block text-gray-300 text-sm font-semibold mb-2">Email Address</label>
                                <input id="email" type="email" class="appearance-none border rounded w-full py-3 px-4 text-gray-200 bg-gray-800 focus:outline-none focus:ring-2 focus:ring-yellow-500 transition duration-300" name="email" required>
                            </div>
                            <div class="mb-6">
                                <label for="password" class="block text-gray-300 text-sm font-semibold mb-2">Password</label>
                                <input id="password" type="password" class="appearance-none border rounded w-full py-3 px-4 text-gray-200 bg-gray-800 focus:outline-none focus:ring-2 focus:ring-yellow-500 transition duration-300" name="password" required>
                            </div>
                            <div class="flex items-center justify-between">
                                <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-3 px-6 rounded focus:outline-none focus:shadow-outline transition duration-300 transform hover:scale-105">
                                    LOGIN
                                </button>
                                <a class="inline-block align-baseline font-bold text-sm text-yellow-500 hover:text-yellow-400 transition duration-300" href="#">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>

        <footer class="bg-black bg-opacity-80 py-8">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                        <h5 class="text-xl font-oswald font-bold text-yellow-500 mb-4">JOB PORTAL</h5>
                    </div>
                    <div>
                        <h5 class="text-xl font-oswald font-bold text-yellow-500 mb-4">Quick Links</h5>
                        <ul class="space-y-2">
                            <li><a href="#" class="text-gray-300 hover:text-yellow-500 transition duration-300">Home</a></li>
                            <li><a href="#" class="text-gray-300 hover:text-yellow-500 transition duration-300">About</a></li>
                            <li><a href="#" class="text-gray-300 hover:text-yellow-500 transition duration-300">Contact</a></li>
                        </ul>
                    </div>
                    <div>
                        <h5 class="text-xl font-oswald font-bold text-yellow-500 mb-4">Contact Us</h5>
                        <address class="text-gray-300">
                            456 Career Lane<br>
                            Job City, JC 98765<br>
                            Phone: (987) 654-3210
                        </address>
                    </div>
                </div>
                <hr class="my-6 border-gray-700">
                <div class="text-center text-gray-300">
                    <p>&copy; 2024 Job Portal. All rights reserved.</p>
                </div>
            </div>
        </footer>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
    <script>
        $(function() {
            var loginForm = $("#loginForm");
            if (loginForm.length) {
                loginForm.validate({
                    rules: {
                        email: { required: true, email: true },
                        password: { required: true }
                    },
                    messages: {
                        email: { required: "Please enter your email address.", email: "Enter a valid email." },
                        password: { required: "Please enter your password." }
                    },
                    errorElement: 'span',
                    errorPlacement: function(error, element) {
                        error.addClass('text-red-500 text-xs italic mt-1');
                        element.closest('div').append(error);
                    },
                });
            }
        });
    </script>
</body>
</html>
