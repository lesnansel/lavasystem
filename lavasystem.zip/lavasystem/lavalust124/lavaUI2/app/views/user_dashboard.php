<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Job Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 min-h-screen flex flex-col">
            <div class="p-4">
                <h2 class="text-2xl font-bold">Job Portal</h2>
            </div>
            <nav class="flex-1">
                <a href="#" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-user mr-2"></i> Profile
                </a>
                <a href="<?=site_url('dashboard')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                </a>
                <a href="<?=site_url('jobs')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-briefcase mr-2"></i> View Jobs
                </a>
                <a href="<?=site_url('applications')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-file-alt mr-2"></i> My Applications
                </a>
                <a href="<?=site_url('messages')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-envelope mr-2"></i> Messages
                </a>
                <a href="<?=site_url('saved-jobs')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-bookmark mr-2"></i> Saved Jobs
                </a>
            </nav>
            <div class="p-4">
                <a href="<?=site_url('logout')?>" class="block py-2 px-4 bg-red-500 text-white rounded hover:bg-red-600 transition duration-200">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main content -->
        <div class="flex-1 p-10">
            <h1 class="text-3xl font-bold mb-8">Dashboard</h1>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Total Applications Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">Total Applications</h2>
                    <p class="text-3xl font-bold text-center">15</p>
                </div>

                <!-- Active Job Listings Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">Active Job Listings</h2>
                    <p class="text-3xl font-bold text-center">8</p>
                </div>

                <!-- New Messages Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">New Messages</h2>
                    <p class="text-3xl font-bold text-center">3</p>
                </div>
            </div>

            <!-- Applications Status Chart -->
            <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Applications Status</h2>
                <div id="applicationsStatusChart" class="w-full h-64"></div>
            </div>

            <!-- Recently Saved Jobs -->
            <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Recently Saved Jobs</h2>
                <ul>
                    <li class="py-2 border-b">Frontend Developer at XYZ Corp</li>
                    <li class="py-2 border-b">Backend Developer at ABC Inc</li>
                    <li class="py-2 border-b">Project Manager at LMN Ltd</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Applications Status Chart
        new Chart(document.getElementById('applicationsStatusChart'), {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'Accepted', 'Rejected'],
                datasets: [{
                    data: [5, 8, 2],
                    backgroundColor: ['#FFA000', '#4CAF50', '#F44336']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                title: {
                    display: true,
                    text: 'Applications Status'
                }
            }
        });
    </script>
</body>
</html>
