<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Messages</title>
    <link rel="stylesheet" href="path/to/bootstrap.css">
</head>
<body>
    <div class="container">
        <h1>Messages</h1>
        <div class="message-list">
            <?php foreach ($messages as $message): ?>
                <div class="message-item">
                    <strong><?= $message['sender_name']; ?>:</strong>
                    <p><?= $message['message']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
        <form action="<?= site_url('message/send'); ?>" method="POST">
            <input type="hidden" name="receiver_id" value="<?= $receiver_id; ?>">
            <textarea name="message" class="form-control" required></textarea>
            <button type="submit" class="btn btn-primary">Send</button>
        </form>
    </div>
</body>
</html>