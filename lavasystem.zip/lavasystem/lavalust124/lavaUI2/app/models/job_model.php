<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Job_model extends Model {
    
    // Fetch all jobs from the database
    public function read() {
        return $this->db->table('Jobs')->get_all();
    }

    // Add a new job listing
    public function create($title, $description, $requirements, $salary, $location, $company, $job_type) {
        $job_data = array(
            'title' => $title,
            'description' => $description,
            'requirements' => $requirements,
            'salary' => $salary,
            'location' => $location,
            'company' => $company,
            'job_type' => $job_type,
        );
        return $this->db->table('Jobs')->insert($job_data);
    }

    // Get a single job listing by ID
    public function get_one($job_id) {
        return $this->db->table('Jobs')->where('JobID', $job_id)->get();
    }

    // Update an existing job listing
    public function update($job_id, $data)
{
    // Prepare the data array for update, matching the new table schema
    $job_data = [
        'Title' => $data['title'], // Updated to match the new column name 'Title'
        'Description' => $data['description'],
        'Requirements' => $data['requirements'],
        'Salary' => $data['salary'],
        'Location' => $data['location'],
        'Company' => $data['company'],
        'JobType' => $data['job_type'],
        // 'PostingDate' is automatically set by the database (CURRENT_TIMESTAMP)
    ];

    // Update the job posting in the database
    return $this->db->table('Jobs')
                    ->where('JobID', $job_id) // Use 'JobID' instead of 'id' as per the table structure
                    ->update($job_data);
}

    // Delete a job listing
    public function delete($job_id) {
        return $this->db->table('Jobs')->where('id', $job_id)->delete();
    }

    // Bookmark a job for a specific user
    public function bookmark_job($user_id, $job_id) {
        $bookmark_data = array(
            'user_id' => $user_id,
            'job_id' => $job_id
        );
        return $this->db->table('Bookmarks')->insert($bookmark_data);
    }

    // Get all bookmarked jobs for a user
    public function get_bookmarked_jobs($user_id) {
        return $this->db->table('Bookmarks')
                        ->select('Jobs.*')
                        ->join('Jobs', 'Bookmarks.job_id = Jobs.id')
                        ->where('Bookmarks.user_id', $user_id)
                        ->get_all();
    }

    // Apply for a job
    public function apply($job_id, $user_id, $cover_letter) {
        $application_data = array(
            'job_id' => $job_id,
            'user_id' => $user_id,
            'cover_letter' => $cover_letter,
            'status' => 'Pending', // Default application status
            'applied_at' => date('Y-m-d H:i:s'),
        );
        return $this->db->table('Applications')->insert($application_data);
    }

    // Fetch all applications for a specific user
    public function get_user_applications($user_id) {
        return $this->db->table('Applications')
                        ->select('Jobs.*, Applications.status, Applications.applied_at')
                        ->join('Jobs', 'Applications.job_id = Jobs.id')
                        ->where('Applications.user_id', $user_id)
                        ->get_all();
    }

    // Fetch all applications for a specific job (for employers)
    public function get_job_applications($job_id) {
        return $this->db->table('Applications')
                        ->select('Users.name, Users.email, Applications.cover_letter, Applications.status')
                        ->join('Users', 'Applications.user_id = Users.id')
                        ->where('Applications.job_id', $job_id)
                        ->get_all();
    }
}
?>
