<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Job_model extends Model {

    // Fetch all job listings
    public function read() {
        return $this->db->table('Jobs')->get_all();
    }

    // Create a new job listing
    public function create($title, $description, $requirements, $salary, $location, $company, $job_type) {
        $job_data = array(
            'title' => $title,
            'description' => $description,
            'requirements' => $requirements,
            'salary' => $salary,
            'location' => $location,
            'company' => $company,
            'job_type' => $job_type
        );
        return $this->db->table('Jobs')->insert($job_data);
    }

    // Get a specific job listing by ID
    public function get_one($job_id) {
        return $this->db->table('Jobs')->where('id', $job_id)->get();
    }

    // Update a job listing
    public function update($job_id, $data) {
        $job_data = [
            'title' => $data['title'],
            'description' => $data['description'],
            'requirements' => $data['requirements'],
            'salary' => $data['salary'],
            'location' => $data['location'],
            'company' => $data['company'],
            'job_type' => $data['job_type']
        ];
        return $this->db->table('Jobs')->where('id', $job_id)->update($job_data);
    }

    // Delete a job listing
    public function delete($job_id) {
        return $this->db->table('Jobs')->where('id', $job_id)->delete();
    }

    // Apply for a job
    public function apply($job_id, $user_id, $cover_letter) {
        $application_data = array(
            'job_id' => $job_id,
            'user_id' => $user_id,
            'cover_letter' => $cover_letter,
            'status' => 'Pending', // Default status
            'applied_at' => date('Y-m-d H:i:s'),
        );
        return $this->db->table('Applications')->insert($application_data);
    }

    // Delete a user's application for a job
    public function delete_application($application_id) {
        return $this->db->table('Applications')->where('id', $application_id)->delete();
    }

    // Bookmark a job for a user
    public function bookmark_job($user_id, $job_id) {
        $bookmark_data = array(
            'user_id' => $user_id,
            'job_id' => $job_id
        );
        return $this->db->table('Bookmarks')->insert($bookmark_data);
    }
}
?>
